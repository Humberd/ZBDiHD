CREATE FUNCTION name(a INT)
  RETURN INT AS
  BEGIN
    return a;
  END;
/

