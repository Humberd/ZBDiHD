CREATE TRIGGER T_ID_WSKLEP
  BEFORE INSERT
  ON W_SKLEP
  FOR EACH ROW
  BEGIN
    :new.id := sek_wsklep.nextval;
  END;
/

