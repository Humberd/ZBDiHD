CREATE FUNCTION aaa
  RETURN NUMBER IS
  average NUMBER;
  BEGIN
    average := 1;
    --     SELECT AVG(w.salary)
    --     INTO average
    --     FROM Worker w, POSITION p
    --     WHERE w.position_id = p.id
    --           AND p.name = position_name;
  END;
/

