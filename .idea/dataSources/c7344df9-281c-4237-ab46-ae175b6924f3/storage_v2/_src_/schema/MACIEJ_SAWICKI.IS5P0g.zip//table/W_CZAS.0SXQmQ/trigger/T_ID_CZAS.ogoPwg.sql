CREATE TRIGGER T_ID_CZAS
  BEFORE INSERT
  ON W_CZAS
  FOR EACH ROW
  BEGIN
    :new.id := sek_czas.nextval;
  END;
/

