CREATE TRIGGER T_ID_FREKLAMA
  BEFORE INSERT
  ON F_REKLAMA
  FOR EACH ROW
  BEGIN
    :new.id := sek_freklama.nextval;
  END;
/

