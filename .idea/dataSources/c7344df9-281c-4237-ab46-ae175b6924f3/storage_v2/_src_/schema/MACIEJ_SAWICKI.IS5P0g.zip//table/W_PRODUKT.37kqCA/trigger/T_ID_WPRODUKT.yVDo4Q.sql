CREATE TRIGGER T_ID_WPRODUKT
  BEFORE INSERT
  ON W_PRODUKT
  FOR EACH ROW
  BEGIN
    :new.id := sek_wprodukt.nextval;
  END;
/

