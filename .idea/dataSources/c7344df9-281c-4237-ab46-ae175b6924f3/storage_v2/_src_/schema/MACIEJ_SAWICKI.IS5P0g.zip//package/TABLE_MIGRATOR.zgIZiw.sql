CREATE PACKAGE table_migrator AS
  PROCEDURE migrate_tables;
END;
/

