CREATE PACKAGE BODY table_migrator
AS
  PROCEDURE migrate_tables
  AS
    BEGIN
      FOR i IN (SELECT DISTINCT t.POSITION
                FROM TEMP t) LOOP
        INSERT INTO Position VALUES (generate_position_id.nextval, i.POSITION);
      END LOOP;

      FOR i IN (SELECT DISTINCT t.SPECIALITY
                FROM TEMP t) LOOP
        INSERT INTO Speciality VALUES (generate_speciality_id.nextval, i.SPECIALITY);
      END LOOP;
    END migrate_tables;
END table_migrator;
/

