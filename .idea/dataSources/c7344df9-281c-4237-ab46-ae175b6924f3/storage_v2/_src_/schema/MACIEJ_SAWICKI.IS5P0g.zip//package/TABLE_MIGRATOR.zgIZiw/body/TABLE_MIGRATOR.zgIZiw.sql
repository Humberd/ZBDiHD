CREATE PACKAGE BODY table_migrator
AS
  PROCEDURE migrate_tables AS
    BEGIN
      -- TEMP -> Position
      FOR i IN (SELECT DISTINCT t.POSITION
                FROM TEMP t) LOOP
        INSERT INTO Position VALUES (generate_position_id.nextval, i.POSITION);
      END LOOP;

      -- TEMP -> Speciality
      FOR i IN (SELECT DISTINCT t.SPECIALITY
                FROM TEMP t) LOOP
        INSERT INTO Speciality VALUES (generate_speciality_id.nextval, i.SPECIALITY);
      END LOOP;

      -- TEMP -> Worker
      FOR i IN (SELECT
                  t.name,
                  t.surname,
                  t.BIRTH,
                  t.email,
                  t.hire_date,
                  t.salary,
                  t.POSITION,
                  t.SPECIALITY
                FROM TEMP t) LOOP
        INSERT INTO Worker
        VALUES (generate_worker_id.nextval,
                i.NAME,
                i.SURNAME,
                i.BIRTH,
                i.EMAIL,
                i.HIRE_DATE,
                i.SALARY,
                (SELECT p.id
                 FROM Position p
                 WHERE p.name = i.POSITION),
                (SELECT s.id
                 FROM Speciality s
                 WHERE s.name = i.SPECIALITY));
      END LOOP;

      EXCEPTION
      WHEN OTHERS
      THEN NULL;
    END migrate_tables;

  -- calculate_mean_salary
  FUNCTION calculate_mean_salary(position_name Position.name%TYPE)
    RETURN NUMBER IS
    average NUMBER;
    BEGIN
      SELECT AVG(w.salary)
      INTO average
      FROM Worker w, POSITION p
      WHERE w.position_id = p.id
            AND p.name = position_name;
      RETURN average;
    END;
END table_migrator;
/

