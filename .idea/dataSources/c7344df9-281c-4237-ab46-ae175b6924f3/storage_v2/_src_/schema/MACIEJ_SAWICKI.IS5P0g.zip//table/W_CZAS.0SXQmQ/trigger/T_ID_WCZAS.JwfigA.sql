CREATE TRIGGER T_ID_WCZAS
  BEFORE INSERT
  ON W_CZAS
  FOR EACH ROW
  BEGIN
    :new.id := sek_wczas.nextval;
  END;
/

