CREATE TRIGGER SALARY_GUARD
  BEFORE INSERT OR UPDATE OF SALARY, POSITION_ID
  ON WORKER
  FOR EACH ROW
  DECLARE
    position_name  VARCHAR(100);
    average_salary NUMBER;
      salaryException EXCEPTION;
  BEGIN
    SELECT Position.name
    INTO position_name
    FROM Position
    WHERE ID = :new.position_id;

    average_salary := task2.calculate_mean_salary(position_name);
    dbms_output.put_line('avg ' || average_salary);
    IF (average_salary * 1.25) < :new.salary
    THEN
      RAISE salaryException;
    END IF;
  END;
/

