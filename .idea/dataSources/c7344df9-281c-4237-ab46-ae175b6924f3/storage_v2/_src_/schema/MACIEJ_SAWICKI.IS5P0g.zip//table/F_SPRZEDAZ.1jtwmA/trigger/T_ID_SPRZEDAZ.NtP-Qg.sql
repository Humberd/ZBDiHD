CREATE TRIGGER T_ID_SPRZEDAZ
  BEFORE INSERT
  ON F_SPRZEDAZ
  FOR EACH ROW
  BEGIN
    :new.id := sek_sprzedaz.nextval;
  END;
/

