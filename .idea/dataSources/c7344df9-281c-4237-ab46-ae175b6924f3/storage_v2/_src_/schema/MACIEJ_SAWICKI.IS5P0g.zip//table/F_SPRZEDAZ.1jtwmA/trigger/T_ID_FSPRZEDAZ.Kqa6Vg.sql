CREATE TRIGGER T_ID_FSPRZEDAZ
  BEFORE INSERT
  ON F_SPRZEDAZ
  FOR EACH ROW
  BEGIN
    :new.id := sek_fsprzedaz.nextval;
  END;
/

