CREATE TRIGGER T_ID_KATEGORII
  BEFORE INSERT
  ON W_KATEGORIA
  FOR EACH ROW
  BEGIN
    :new.id := sek_kategoria.nextval;
  END;
/

