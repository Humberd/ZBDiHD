CREATE TRIGGER T_ID_WPANSTWO
  BEFORE INSERT
  ON W_PANSTWO
  FOR EACH ROW
  BEGIN
    :new.id := sek_wpanstwo.nextval;
  END;
/

