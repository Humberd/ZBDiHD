CREATE PACKAGE task2 AS
  PROCEDURE migrate_tables;

  FUNCTION calculate_mean_salary(position_name Position.name%TYPE)
    RETURN NUMBER;
END;
/

