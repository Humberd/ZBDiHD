CREATE FUNCTION calculate_mean_salary(position_name Position.name%TYPE)
  RETURN NUMBER IS
  average NUMBER(10, 2);
  BEGIN
    SELECT AVG(w.salary)
    INTO average
    FROM Worker w, POSITION p
    WHERE w.position_id = p.id
          AND p.name = position_name;
    RETURN average;
  END;
/

