CREATE TRIGGER T_ID_FPROMOCJA
  BEFORE INSERT
  ON F_PROMOCJA
  FOR EACH ROW
  BEGIN
    :new.id := sek_fpromocja.nextval;
  END;
/

