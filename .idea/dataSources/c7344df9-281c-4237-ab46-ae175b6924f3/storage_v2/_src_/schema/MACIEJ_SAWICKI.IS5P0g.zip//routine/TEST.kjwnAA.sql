CREATE FUNCTION test
  RETURN NUMBER is
  average NUMBER;
  BEGIN
    average := 1;
    RETURN average;
  END;
/

